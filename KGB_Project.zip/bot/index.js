const { Client, GatewayIntentBits } = require('discord.js');
const express = require('express');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const app = express();
app.use(express.json());

const TOKEN = "TON_TOKEN_DISCORD";
const CHANNEL_ID = "ID_DU_SALON";

app.post('/login-log', async (req, res) => {
  const { username } = req.body;
  const channel = await client.channels.fetch(CHANNEL_ID);
  if (channel) {
    channel.send(`🕵️ ${username} s'est connecté au KGB`);
  }
  res.send("ok");
});

client.once('ready', () => console.log("Bot prêt"));
client.login(TOKEN);

app.listen(3000);
