const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

let messages = [];

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if(password === "@2008"){
    res.json({success:true});
  } else {
    res.json({success:false});
  }
});

io.on('connection', (socket)=>{
  socket.on('join', (user)=>{
    socket.user = user;
    socket.emit('load', messages);
  });

  socket.on('msg', (msg)=>{
    const full = socket.user + " : " + msg;
    messages.push(full);
    io.emit('msg', full);
  });
});

server.listen(5000);
